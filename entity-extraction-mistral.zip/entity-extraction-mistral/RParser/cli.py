import os
import time
import json
import re
import torch
import psutil
from pathlib import Path

from resumeparser import ResumeParser
from utils.logger import Logger

class Cli:
    pass




def main():
    
    # parser = argparse.ArgumentParser(description="Resume Parser Arguments")
    # parser.add_argument("--task", type=str, choices=["Parse From Single File", "Parse From Directory"], required=True,  help="Task/Method name to be performed")
    # parser.add_argument("--filepath", type=int, help="File path of Resume, Required in case Parse From Single File")
    # parser.add_argument("--inputdir", type=int, help="Directory path of Resumes, Required in case Parse From Directory")
    
    # args = parser.parse_args()
    
    # if(args.task == "Parse From Single File" and args.filepath is None):
    #     parser.error("--filepath is required when --task is 'Parse From Single File'")

    # if(args.task == "Parse From Directory" and args.inputdir is None):
    #     parser.error("--inputdir is required when --task is 'Parse From Directory'")

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    # Start time for execution tracking
    start_time = time.time()
    
    # Monitor initial system resource usage
    cpu_start = psutil.cpu_percent(interval=None)
    ram_start = psutil.virtual_memory().percent
    gpu_start = torch.cuda.memory_allocated() / 1e9 if torch.cuda.is_available() else None

    logger = Logger()
    resumeParser = ResumeParser(_logger=logger)
    path = Path("./Resume1.pdf")
    inputFilePath = str(path.resolve())
    outputfilename = f'{inputFilePath.replace(".pdf","")}_output.json'

    hasJsonResult, finalResult = resumeParser.parseSingleResume(filepath=inputFilePath,question = "Extract key information from this resume and return as JSON only. Do not add any comment or note in output.")

    if hasJsonResult:
        with open(outputfilename, 'w') as f:
            f.write(finalResult)
        final_result_print =  f"Extracted Entities saved in '{outputfilename}'"
    else:
        # Save raw result
        with open('./result_generated.txt', 'w') as f:
            f.write(finalResult)
        final_result_print ="Failed to parse JSON. Raw output saved in 'result_generated.txt'."

    # Monitor system resource usage after execution
    cpu_end = psutil.cpu_percent(interval=None)
    ram_end = psutil.virtual_memory().percent
    gpu_end = torch.cuda.memory_allocated() / 1e9 if torch.cuda.is_available() else None

    # Compute execution time
    execution_time = time.time() - start_time

    # Print Performance Summary
    print("\n=====  Execution Analysis Report =====")
    print(f"- Execution Time: {execution_time:.2f} sec")
    print(f"- Input Tokens: {logger.getLogByKey("input_tokens")}")
    print(f"- Total Input Tokens: {logger.getLogByKey("prompt_tokens")+logger.getLogByKey("input_tokens")}")
    print(f"- Output Tokens: {logger.getLogByKey("output_tokens")}")
    print(f"- Total Tokens (Input + Output): {logger.getLogByKey("input_tokens") + logger.getLogByKey("output_tokens")}")
    print(f"- CPU Usage: {cpu_start}% → {cpu_end}%")
    print(f"- RAM Usage: {ram_start}% → {ram_end}%")
    if gpu_start is not None and gpu_end is not None:
        print(f"- GPU Memory Used: {gpu_start:.2f} GB → {gpu_end:.2f} GB")
    print("=================================\n")
    print(final_result_print)


if __name__ == "__main__":
    main()