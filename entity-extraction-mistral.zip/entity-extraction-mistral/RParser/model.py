import os
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
# from huggingface_hub import login
from langchain.chains import  LLMChain
from langchain_community.llms import HuggingFacePipeline
from collections import namedtuple

LoadModelResult = namedtuple("LoadModelResult", ["tokenizer", "model", "pipe", "llm"])

class ResumeParseModel:
    model_instance = None

    MODEL_NAME = "mistralai/Mistral-7B-Instruct-v0.3"
    MODEL_TASK = "text-generation"

    def __new__(cls, config):
        if cls.model_instance is None:
            cls.model_instance = super(ResumeParseModel,cls).__new__(cls)
            cls.model_instance.model = cls.load_model(config=config)
            


    @staticmethod
    def load_model(config):
        ## Login To Huggingface
        # login(token=config.HF_TOKEN)

        tokenizer = AutoTokenizer.from_pretrained(config.MODEL_NAME)
        model = AutoModelForCausalLM.from_pretrained(
            config.MODEL_NAME,
            trust_remote_code=False,
            torch_dtype=torch.bfloat16,
            device_map="auto"
        ).eval()

        model = torch.compile(model)

        # Create a Hugging Face pipeline
        pipe = pipeline(
            ResumeParseModel.MODEL_TASK,
            model=model,
            tokenizer=tokenizer,
            max_new_tokens=config.MAX_NEW_TOKEN,
            temperature=config.TEMPREATURE,
            repetition_penalty=config.REPETITION_PENALTY,
            do_sample=False,
            return_full_text=False    
        )

        # Initialize LangChain HuggingFacePipeline
        llm = HuggingFacePipeline(pipeline=pipe)

        return LoadModelResult(tokenizer, model, pipe, llm)

    
    def getResult(cls, prompt,dictContext):
        chain = LLMChain(llm=cls.model.llm, prompt=prompt)
        result = chain.run(context=dictContext["context"], question=dictContext["question"])
        return result