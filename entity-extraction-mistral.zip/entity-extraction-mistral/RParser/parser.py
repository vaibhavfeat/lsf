import re
import os
import argparse
import json
import json_repair
from RParser.utils.config import Config
from RParser.utils.date_parse import DateParse
# from RParser.utils.file import ReadPDF,ReadPromptTemplateFile
from RParser.utils.file import ReadPromptTemplateFile
from RParser.model import ResumeParseModel
from langchain.prompts import PromptTemplate


class RParser:
    modelinstance = None
    
    def __init__(self, _logger):
        ResumeParseModel(Config)
        self.modelinstance = ResumeParseModel.model_instance
        self.logger = _logger
        self.dateParser = DateParse()
    
    def parseSingleResume(self, str_file_base64_content, question):
        
        prompt_template = ReadPromptTemplateFile(file_path=Config.PROMPT_TEMPLATE)

        prompt = PromptTemplate(
        input_variables=["context", "question"],
        template=prompt_template)

        # context = ReadPDF(filepath)
        context= str_file_base64_content

        self.logger.addLog( "prompt_tokens" , len(self.modelinstance.model.tokenizer.encode(prompt_template)))
        self.logger.addLog( "input_tokens" , len(self.modelinstance.model.tokenizer.encode(context)))
        
        # chain = LLMChain(llm=self.modelinstance.model.llm, prompt=prompt)
        # result = chain.run(context=context, question=question)
        result = self.modelinstance.getResult(prompt,{"context":context, "question":question}) 

        self.logger.addLog( "output_tokens" , len(self.modelinstance.model.tokenizer.encode(result)))
        
        return self.processResult(result)
    
    def parseFromDirectory(directoryPath):
        pass
    
    def processResult(self,result):
        hasJsonResult = False
        finalResult =result
        
        # Parse JSON Output
        matches = re.findall(r"\{.*\}", result, re.DOTALL)
        result = matches[0] if matches else result
        result = re.sub(r'\[([^\]]+)\]\(mailto:[^)]+\)', r'\1', result)  # Fix email format
        result = re.sub(r"^//.*$", "", result, flags=re.MULTILINE)


        try:
            entities = json_repair.loads(result)

            # if "Total_Experience" in entities and entities["Total_Experience"] \
            # and entities["Total_Experience"].lower() not in ('unknown','not available'):
            #     total_experience = self.dateParser.convert_experience_to_months(entities["Total_Experience"])
            #     compute_type = 'Exact'
            # else:
            #     total_experience = self.dateParser.compute_total_experience(entities.get("Experience", []),entities.get("Total_Experience",None))
            #     compute_type = 'Approx'

            # entities["Total_Experience"] = total_experience
            # entities["ComputationType"] = compute_type

            # finalResult = json.dumps(entities, indent=2)
            finalResult = entities
            hasJsonResult=True
            
        except json.JSONDecodeError as e:
            pass

        return hasJsonResult,finalResult