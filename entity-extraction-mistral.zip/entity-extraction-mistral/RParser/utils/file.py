import os
from pathlib import Path
# from langchain_community.document_loaders import PyPDFLoader
path = Path()

# def ReadPDF(pdf_file_path):
#     loader = PyPDFLoader(pdf_file_path)  # Replace with your PDF path
#     pages = loader.load()
#     return " ".join([page.page_content for page in pages])

def ReadPromptTemplateFile(file_path):
    with open(file_path , "r", encoding="utf-8") as file:
        return file.read()