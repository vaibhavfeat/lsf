import os
import re
import time
from datetime import datetime

class DateParse:

    def parse_date(self,date_str):
        
        """
        Parse various formats like "Oct 2024", "2024-04", "2024-Oct", "Oct-2024", "Oct 24", etc.
        Returns date in 'YYYY-MM' format or 'Invalid Format' if parsing fails.
        """
        if date_str.lower() =='not available':
            return None

        # Standard month name mapping (for short and full month names)
        month_map = {month: f"{i:02d}" for i, month in enumerate([
            "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ], 1)}

        # Standardize separator to "-"
        date_str = date_str.replace(" ", "-").replace("/", "-").replace("'", " ")

        # Regex patterns to match different formats
        patterns = [
            r"(?P<month>\w+)[- ]?(?P<year>\d{4})",  # Oct 2024, Oct-2024, Oct-24
            r"(?P<year>\d{4})[- ]?(?P<month>\w+)",  # 2024-04, 2024-Oct
            r"(?P<year>\d{2})[- ]?(?P<month>\w+)",  # 24-Oct, 24 Oct
            r"(?P<month>\w+)[- ](?P<year>\d{2})"    # Oct 23
        ]
        if date_str is None:
            return datetime.today()
        
        for pattern in patterns:
            
            match = re.match(pattern, date_str, re.IGNORECASE)
            if match:
                data = match.groupdict()

                # Convert 2-digit year to full year (assuming 2000+)
                year = data["year"]
                if len(year) == 2:
                    year = "20" + year  # Convert '24' → '2024'

                # Convert month name to number
                month = data["month"].capitalize()[:3]  # Normalize to 3-letter format
                if month.isdigit():
                    month_num =  int(month)
                elif month in month_map:
                    month_num = int(month_map[month])

                return datetime (int(year), month_num, 1)

        return datetime.today()
        

    def compute_total_experience(self,work_experience,total_experience):
        """Computes the total unique experience in months from the work experience list."""
        date_ranges = []
        
        for job in work_experience:
            if(total_experience is not None and job["Employment_From"] == total_experience ):
                return self.convert_experience_to_months(total_experience)

            start_date = self.parse_date(job["Employment_From"])
            end_date = datetime.today() if job["Employment_To"] is None \
                or  ( job["Employment_To"].lower() == "present" or \
                    job["Employment_To"].lower() == "current") else self.parse_date(job["Employment_To"])
            
            if(start_date and end_date):
                job["Employment_From"] = start_date.strftime("%Y-%b")
                if job["Employment_To"] is not None \
                    and  ( job["Employment_To"].lower() != "present" and \
                    job["Employment_To"].lower() != "current"):            
                    job["Employment_To"]= end_date.strftime("%Y-%b")

            date_ranges.append((start_date, end_date))
        
        if len(date_ranges)==0:
            return 0
        # Sort the date ranges by start date
        date_ranges.sort()
        
        total_months = 0
        current_start, current_end = date_ranges[0]
        
        for start, end in date_ranges[1:]:
            if start <= current_end:  # Overlapping period
                current_end = max(current_end, end)
            else:
                total_months += (current_end.year - current_start.year) * 12 + (current_end.month - current_start.month)
                current_start, current_end = start, end
        
        # Add the last range
        total_months += (current_end.year - current_start.year) * 12 + (current_end.month - current_start.month)
        
        return total_months

    def convert_experience_to_months(self,experience):
        """
        Converts total experience string into months.
        
        Supported formats:
        - "2.5 years" → 30 months
        - "2+ years" → 24 months
        - "2 years 4 months" → 28 months
        - "3 years" → 36 months
        """
        if experience is None:
            return None

        experience = experience.lower()

        # Regex patterns for different formats
        year_month_pattern = re.match(r"(\d+)\s*years?\s*(\d+)\s*months?", experience)
        decimal_year_pattern = re.match(r"(\d+\.?\d*)\s*years?", experience)
        plus_year_pattern = re.match(r"(\d+)\+\s*years?", experience)
        only_months_pattern = re.match(r"(\d+)\s*months?", experience)

        if year_month_pattern:
            years = int(year_month_pattern.group(1))
            months = int(year_month_pattern.group(2))
        elif decimal_year_pattern:
            years = float(decimal_year_pattern.group(1))
            months = int(years * 12)  # Convert years to months
        elif plus_year_pattern:
            years = int(plus_year_pattern.group(1))
            months = years * 12  # Convert years to months
        elif only_months_pattern:
            months = int(only_months_pattern.group(1))        
        else:
            return None  # Unsupported format

        return months

