import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Configuration class that loads environment variables."""
    
    MAX_NEW_TOKEN = int(os.getenv("MAX_NEW_TOKEN", 1500))
    TEMPREATURE = int(os.getenv("TEMPREATURE",0))
    REPETITION_PENALTY = float( os.getenv("REPETITION_PENALTY", 1.2))
    HF_TOKEN = os.getenv("HF_TOKEN")
    PROMPT_TEMPLATE= os.getenv("PROMPT_TEMPLATE")
    MODEL_NAME= os.getenv("MODEL_NAME")

