class Logger:
    logs={}

    def addLog(self, key,value):
        self.logs[key]=value
    
    def getLogByKey(self, key):
        if key in self.logs:
            return self.logs[key] 