import os
import time
os.environ["HF_HOME"]="E:\\huggingface\\cache\\"
from dotenv import load_dotenv
from typing import List, Dict, Optional
from label_studio_ml.model import LabelStudioMLBase
from label_studio_ml.response import ModelResponse
import torch
import psutil

load_dotenv()  

from Resume_Parser import ResumeParser
from Resume_Parser.utils.logger import Logger
from Resume_Parser.utils.config import Config

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

class ResumeParserModel(LabelStudioMLBase):
    """Custom ML Backend model
    """
    
    def setup(self):
        """Configure any parameters of your model here
        """
        self.set("model_version", "0.0.1")

    def predict_external(self, texts, **kwargs) -> ModelResponse:
        """ Write your inference logic here
            :param texts: [List of text in JSON format]
            :return model_response
                ModelResponse(predictions=predictions) with
                predictions: [Predictions array in JSON format](https://labelstud.io/guide/export.html#Label-Studio-JSON-format-of-annotated-tasks)
        """
        # print(f'''\
        # Run prediction on {texts}
        # Project ID: {self.project_id}
        # Label config: {self.label_config}
        # Parsed JSON Label config: {self.parsed_label_config}
        # Extra params: {self.extra_params}''')


        Config.PROMPT_TEMPLATE = self.getModelRootDirectory()+"\\prompt_templates\\prompt_default.txt"

        logger = Logger()
        resumeParser = ResumeParser(_logger=logger)

        result = []

        for text in texts:

          start_time = time.time()
          
          # Monitor initial system resource usage
          cpu_start = psutil.cpu_percent(interval=None)
          ram_start = psutil.virtual_memory().percent
          gpu_start = torch.cuda.memory_allocated() / 1e9 if torch.cuda.is_available() else None

          request_id =None

          if not isinstance(text, str):
            request_id = text["id"]
            text = text["text"]     

          hasJsonResult, finalResult = resumeParser \
              .parseSingleResume(str_file_base64_content=text, \
              question = "Extract key information from this resume and return as JSON only. Do not add any comment or note in output.")

          # Monitor system resource usage after execution
          cpu_end = psutil.cpu_percent(interval=None)
          ram_end = psutil.virtual_memory().percent
          gpu_end = torch.cuda.memory_allocated() / 1e9 if torch.cuda.is_available() else None

          # Compute execution time
          execution_time = time.time() - start_time


          analysis_result = {
              "execution_time":f"{execution_time:.2f} sec",
              "input_tokens":logger.getLogByKey("input_tokens"),
              "total_input_tokens":logger.getLogByKey("prompt_tokens")+logger.getLogByKey("input_tokens"),
              "output_tokens":logger.getLogByKey("output_tokens"),
              "total_tokens":logger.getLogByKey("input_tokens") + logger.getLogByKey("output_tokens"),
              "cpu_usage":f"{cpu_start}% → {cpu_end}%",
              "ram_usage":f"{ram_start}% → {ram_end}%",
              "gpu_usage":f"{gpu_start:.2f} GB → {gpu_end:.2f} GB" if  gpu_start is not None and gpu_end is not None else "",
          }


          result.append( {
              "id":request_id,
              "from_name": "instruction",
              "to_name": "prompt",
              "type": "textarea",
              "value": {
                "text": [
                  finalResult
                ],
                "type": "json" if hasJsonResult else "raw",
                "report":analysis_result
              }
            })


        predictions = [{
            "model_version": self.get("model_version"),
            "score": 0.99,
            "result": result
        }]

        
        return ModelResponse(predictions=predictions)
        

