// const wincred = require('wincred');

// const targetName = 'password'; // the name under which the credential is stored

// try {
//     const credential = wincred.getCredential(targetName);
//     if (credential) {
//         console.log('Username:', credential.username);
//         console.log('Password:', credential.password);
//     } else {
//         console.log('Credential not found.');
//     }
// } catch (error) {
//     console.error('Error reading credential:', error.message);
// }


const { CredentialManager } = require('@strychnine-labs/windows-credential-manager');

const credManager = new CredentialManager();
const target = 'actionabl/db/password'; // This is the "Internet or network address"
// in Credential Manager for a Generic Credential

async function getMyCredential() {
    try {
        const credential = await credManager.getCredential(target);
        if (credential) {
            console.log('Username:', credential.username);
            console.log('Password:', credential.password.replaceAll(target,""));
        } else {
            console.log(`Credential with target "${target}" not found.`);
        }
    } catch (error) {
        console.error('Error retrieving credential:', error);
    }
}

getMyCredential();